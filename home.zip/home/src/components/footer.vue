<template>
  <el-row class="footer-wrapper text-center" :span="24" is="footer">
    兼乎所有---twicetech.top
  </el-row>
</template>

<style lang="scss">
  @import "../style/base/_base";
  @import "../style/base/_color";

  .footer-wrapper {
    height: $footer-height;
    line-height: $footer-height;
    background-color: $website-background-color;
    color: $default-font-color;
    clear: both;
  }
</style>

<script>
  export default {}
</script>

<style>
@import "../../styles/common.less";
</style>
<template>
    <Card :bordered="false" shadow>
        <p slot="title">选择投放帐号</p>
        <p>
            <Row>
                <Col span="12">
                <Select v-model="account_id" placeholder="请选择帐号">
                    <Option v-for="item in mediaList" :value="item.account_id" :key="this">{{ item.account_name }}</Option>
                </Select>

                <Button type="primary" class="margin-top-20" size="large" style="width: 150px;" @click="tonewadd">确定</Button>
                </Col>
            </Row>
        </p>
    </Card>

</template>

<script>
import Axios from "@/api/index";
export default {
    data() {
        return {
            account_id: "",
            mediaList: []
        };
    },
    mounted() {
        this.getMedia();
    },
    methods: {
        //新建广告
        tonewadd() {
            if (this.account_id == "") {
                this.$Message.info("请选择帐号");
                return;
            }

            let query = {
                account_id: this.account_id
            };

            this.$router.push({
                name: "newad",
                query: query
            });
        },
        //获取媒体账号
        getMedia() {
            Axios.get("api.php", {
                action: "api",
                opt: "getAccount",
                MeidaType: "Gdt"
            })
                .then(res => {
                    if (res.ret == 1) {
                        this.mediaList = res.data;
                    }
                })
                .catch(err => {
                    console.log("获取媒体账号" + err);
                });
        }
    }
};
</script>

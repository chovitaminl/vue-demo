<style scoped>
</style>
<template>
    <Select @on-change="mediaChange" placeholder="请选择媒体">
        <Option v-for="(item,index) in media" :value="item.media_type" :key="index">{{ item.cn }}</Option>
    </Select>
</template>
<script>
    import  Axios  from "@/api/index"
	export default {
        name: 'selectMedia',
        props: {
            // placeholder: {
            //     type: String,
            //     default: ''
            // }
        },
		data() {
			return {
                media: []
			}
        },
		methods: {
            //获取全部游戏     
            getMedia(){
                Axios.get('api.php',{'action':'api','opt':'getMedia'})
                .then( 
                    res=>{ 
                        if(res.ret == '1'){
                            let list = res.data;
                            list.unshift({en:'',media_type:'',cn:'全部'});
                            this.media= list;
                        }
                    }
                ).catch( 
                    err=>{ console.log(err) }
                );
            },
			//点击树节点时触发
			mediaChange(data) {
                this.$emit('on-change', data);
			}
        },
        mounted(){       
            this.getMedia();
        }
	}
</script>
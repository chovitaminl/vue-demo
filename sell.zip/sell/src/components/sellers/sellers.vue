<template>
  <div>i am a sellers</div>
</template>
<script type="text/ecmascript-6">
  export default {

  };
</script>
<style lang="stylus" rel="stylesheet/stylus">

</style>

<template>
  <div>
    <v-header :seller="this.seller"></v-header>
    <div class="tab border-1px">
      <div class="tab-item">
        <router-link to="/goods">商品</router-link>
      </div>
      <div class="tab-item">
        <router-link to="/ratings">评价</router-link>
      </div>
      <div class="tab-item">
        <router-link to="/sellers">商家</router-link>
      </div>
    </div>
    <router-view :seller="seller"></router-view>
  </div>
</template>

<script>
  import header from './components/header/header.vue';

  const ERR_OK = 0;
  export default {
    components: {
      'v-header': header
    },
    data() {
      return {
        seller: {}
      };
    },
    created() {
      this.$http.get('/api/seller').then((res) => {
        res = res.body;
        if (res.errno === ERR_OK) {
          this.seller = res.data;
        }
      });
    }
  };

</script>

<style lang="stylus" type="text/stylus">
  @import 'common/stylus/mixin'
  .tab
    display: flex
    width: 100%
    height: 40px
    line-height: 40px
    &.border-1px
      border-1px(rgba(7, 17, 27, 0.1))
    .tab-item
      flex: 1
      text-align: center
      a
        display: block
        color: rgb(77, 85, 93)
        &.active
          color: rgb(243, 22, 101)
</style>
